-----------------------------------------------
Template Name  : my blue construction | Blogger Template
Author         : NewBloggerThemes.com
Author URL     : http://newbloggerthemes.com/
Created Date   : Sunday, January 29, 2012
License        : This template is free for both personal and commercial use, But to satisfy the 'attribution' clause of the license, you are required to keep the footer links intact which provides due credit to its authors.For more information about this license, 
                 please use this link :http://creativecommons.org/licenses/by/3.0/
-----------------------------------------------



Template Setup URL : http://newbloggerthemes.com/my-blue-construction-blogger-template/


---------------------------------------

Template Design/Customization Services :  

---------------------------------------

Want to customize this template as you like ?

Tell me what are the changes you want to do.

contact me :  http://newbloggerthemes.com/contact/



Are you looking for a brand new template design ?

I can do it for you. 

contact me :  http://newbloggerthemes.com/contact/